package ui;

import model.Drink;
import model.lists.DrinkList;
import model.lists.MadeList;
import model.lists.MakingList;
import model.lists.OrderList;

import java.util.Scanner;

public class StarbucksApp {
    private OrderList orderList;
    private MakingList makingList;
    private MadeList madeList;
    private Scanner input;

    // EFFECTS: runs the Starbucks app
    public StarbucksApp() {
        runStarbucks();
    }

    // MODIFIES: this
    // EFFECTS: processes user input
    private void runStarbucks() {
        boolean keepRunning = true;
        String command;

        init();

        while (keepRunning) {
            displayMenu();
            command = input.next();
            command = command.toLowerCase();

            if (command.equals("q")) {
                keepRunning = false;
            } else {
                processCommand(command);
            }
        }

        System.out.println("\n-----Ending Session-----");
    }

    // MODIFIES: this
    // EFFECTS; processes user command
    private void processCommand(String command) {
        switch (command) {
            case "a":
                doAddDrink();
                break;
            case "r":
                doRemoveDrink();
                break;
            case "h":
                doHasDrink();
                break;
            case "g":
                doGetDrink();
                break;
            case "l":
                doListSize();
                break;
            case "s":
                doChangeStatus();
            default:
                System.out.println("-----Invalid Command-----");
                break;
        }
    }

    // MODIFIES: this
    // EFFECTS: initializes drink list
    private void init() {
        orderList = new OrderList();
        makingList = new MakingList();
        madeList = new MadeList();
        input = new Scanner(System.in);
        input.useDelimiter("\n");
    }

    // EFFECTS: displays menu of options to user
    private void displayMenu() {
        System.out.println("\n-----Choose from the following commands: -----");
        System.out.println("\ta -> add a drink");
        System.out.println("\tr -> cancel a drink order");
        System.out.println("\th -> check if the drink list has a drink");
        System.out.println("\tg -> print the information of a drink from the list");
        System.out.println("\tl -> print the drink list size");
        System.out.println("\ts -> change a drink's status and add it to the corresponding list");
        System.out.println("\tq -> quit");
    }

    // MODIFIES: this
    // EFFECTS: add a new drink to the list
    private void doAddDrink() {
        System.out.println("-----What drink would you like? We have Americano, Latte, and Cappuccino!-----");
        String type = input.next();

        System.out.println("-----What size would you like? We have Tall, Grande, and Venti!-----");
        String size = input.next();

        System.out.println("-----May I have your name for the order?-----");
        String name = input.next();

        Drink drink = new Drink(name, model.Drink.Size.valueOf(size), model.Drink.Type.valueOf(type));
        DrinkList.addDrink(drink);

        System.out.println(drink);
    }

    // MODIFIES: this
    // EFFECTS: remove a drink from the list if the drink is not being made or made
    private void doRemoveDrink() {
        System.out.println("-----What's the drink ID?-----");
        int id = input.nextInt();

        if (orderList.removeDrink(id) && orderList.getDrink(id).getStatus() == Drink.Status.Making) {
            orderList.removeDrink(id);
            System.out.println("-----Removed the drink successfully!-----");
        } else {
            System.out.println("-----Invalid drink ID! Please try again!-----");
        }
    }

    // MODIFIES: this
    // EFFECTS: check if a list has a drink
    private void doHasDrink() {
        System.out.println("-----What's the drink ID?-----");
        int id = input.nextInt();

        if (orderList.hasDrink(id)) {
            System.out.println("-----The list has the drink!-----");
        } else {
            System.out.println("-----Invalid drink ID! Please try again!-----");
        }
    }

    // MODIFIES: this
    // EFFECTS: get a drink from the list and display its information
    private void doGetDrink() {
        System.out.println("-----What's the drink ID?-----");
        int id = input.nextInt();

        if (orderList.hasDrink(id)) {
            System.out.println("-----The list has the drink! Below is the information of the drink!-----");
            System.out.println(orderList.getDrink(id));
        } else {
            System.out.println("-----Invalid drink ID! Please try again!-----");
        }
    }

    // EFFECTS: print the size of the list
    private void doListSize() {
        System.out.println("-----The list has " + orderList.listSize() + " drink!-----");
    }

    // REQUIRES: drink to exist in a drink list
    private boolean doChangeStatus() {
        System.out.println("-----What's the drink ID?-----");
        int id = input.nextInt();

        Drink drink;

        for (Drink d: orderList.getList()) {
            if (d.getDrinkID() == id) {
                drink = orderList.getDrink(id);
                drink.changeStatus();
                orderList.removeDrink(id);
                MakingList.addDrink(drink);
                return true;
            }
        }

        for (Drink d: makingList.getList()) {
            if (d.getDrinkID() == id) {
                drink = makingList.getDrink(id);
                drink.changeStatus();
                makingList.removeDrink(id);
                MadeList.addDrink(drink);
                return true;
            }
        }

        return false;
    }
}
